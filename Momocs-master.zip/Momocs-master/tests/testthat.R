library(testthat)
library(Momocs)

test_check("Momocs")

## Test environments
* local OS X 10.10.5 install, R 3.3.1
* ubuntu (on travis-ci), R 3.3.1
* win-builder (release)

## R CMD check results
```
Status: OK
R CMD check succeeded
```
With --as-cran on my machine.

## Reverse dependencies
No reverse dependencies.

